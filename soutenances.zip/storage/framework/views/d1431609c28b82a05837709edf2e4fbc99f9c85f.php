<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('login/fonts/icomoon/style.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('login/css/bootstrap.min.css')); ?>">

    <!-- Style -->
    <link rel="stylesheet" href="<?php echo e(asset('login/css/style.css')); ?>">

    <title>Login #2</title>
  </head>
  <body>


  <div class="d-lg-flex half">
    <div class="bg order-1 order-md-2" style="background-image: url(<?php echo e(asset('login/images/bg_1.jpg')); ?>);"></div>
    <div class="contents order-2 order-md-1">

      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-7">
            <h3>COnnectez vous a <strong>votre espace</strong></h3>
            <p class="mb-4">Veuillez fournir les informations pour vous authentifier.</p>
            <form action="<?php echo e(route('auth')); ?>" method="post">
                <?php echo csrf_field(); ?>
              <div class="form-group first">
                <label for="email">Adresse E-mail</label>
                <input type="email" class="form-control" name="email" placeholder="john@doe.com" id="email">
              </div>
              <div class="form-group last mb-3">
                <label for="password">Mot de passe</label>
                <input type="password" class="form-control" placeholder="***********" name="password" id="password">
              </div>

              <div class="d-flex mb-5 align-items-center">
                <label class="control control--checkbox mb-0"><span class="caption">Se souvenir de moi</span>
                  <input type="checkbox" checked="checked"/>
                  <div class="control__indicator"></div>
                </label>
                <span class="ml-auto"><a href="#" class="forgot-pass">Mot de passe oublie</a></span>
              </div>

              <input type="submit" value="Se connecter" class="btn btn-block btn-primary">

            </form>
          </div>
        </div>
      </div>
    </div>


  </div>



    <script src="<?php echo e(asset('login/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('login/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('login/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('login/js/main.js')); ?>"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\app\soutenances\resources\views/auth/connexion.blade.php ENDPATH**/ ?>