<?php $__env->startSection('main'); ?>

    <div class="col-lg-12 col-12 order-2 order-lg-1">
        <div class="card">
            <div class="card-header">
                <h5>
                Information sur l'article
                </h5>
            </div>
            <div class="card-body">

                <div class="m-5">



                </div>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.articles.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app\soutenance\resources\views/admin/articles/show.blade.php ENDPATH**/ ?>