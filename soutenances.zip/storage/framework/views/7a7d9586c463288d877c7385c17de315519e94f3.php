<?php if($errors->any()): ?>
<div class="alert alert-danger" role="alert">

    <div class="alert-body">
        <strong><i class="me-1" data-feather="alert-triangle"></i>Attention:</strong>
        <br>
        <ul class="mt-3 list-disc list-inside text-sm text-red-600">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php echo e(__($error)); ?>

                    
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\app\soutenances\resources\views/layouts/partials/alert/danger.blade.php ENDPATH**/ ?>