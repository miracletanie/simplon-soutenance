<?php if(session('warning')): ?>
<div class="col-12">
    <div class="alert alert-warning" role="alert">
        <strong><i class="me-1" data-feather="alert-circle"></i> <?php echo e(__(session('Attention'))); ?> :</strong>

        <div class="alert-body">
            
            <?php echo e(session('warning')); ?>

        </div>
    </div>
</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\app\soutenances\resources\views/layouts/partials/alert/warning.blade.php ENDPATH**/ ?>