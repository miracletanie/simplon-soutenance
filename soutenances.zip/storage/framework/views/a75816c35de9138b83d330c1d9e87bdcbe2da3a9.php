  <!-- JavaScript Libraries -->
  <script src="<?php echo e(asset('site/lib/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('site/site/lib/jquery/jquery-migrate.min.js')); ?>"></script>
  <script src="<?php echo e(asset('site/lib/popper/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('site/lib/bootstrap/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('site/lib/easing/easing.min.js')); ?>"></script>
  <script src="<?php echo e(asset('site/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
  <script src="<?php echo e(asset('site/lib/scrollreveal/scrollreveal.min.js')); ?>"></script>
  <!-- Contact Form JavaScript File -->
  <script src="<?php echo e(asset('site/contactform/contactform.js')); ?>"></script>

  <!-- Template Main Javascript File -->
  <script src="<?php echo e(asset('site/js/main.js')); ?>"></script>
<?php /**PATH /Users/macbookpro/Documents/Projects/Perso/Michelle/soutenance/resources/views/site/layouts/includes/js.blade.php ENDPATH**/ ?>