<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Location de viehicule</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <?php echo $__env->make('site.layouts.includes.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- =======================================================
    Theme Name: EstateAgency
    Theme URL: https://bootstrapmade.com/real-estate-agency-bootstrap-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
</head>

<body>

  <div class="click-closed"></div>
  <!--/ Form Search Star /-->
    
  <!--/ Form Search End /-->

  <!--/ Nav Star /-->
    <?php echo $__env->make('site.layouts.includes.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!--/ Nav End /-->

  <?php echo $__env->yieldContent('content'); ?>

  <!--/ footer Star /-->
  
  <?php echo $__env->make('site.layouts.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!--/ Footer End /-->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <div id="preloader"></div>

  <?php echo $__env->make('site.layouts.includes.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\app\soutenances\resources\views/site/layouts/main.blade.php ENDPATH**/ ?>