<?php if(session('success')): ?>

<div class="alert alert-success" role="alert">

    <div class="alert-body">
        <strong><i class="me-1" data-feather="check"></i>Informations :</strong>
        <hr>
        
        <?php echo e(session('success')); ?>

    </div>
</div>
<?php endif; ?>
<?php /**PATH /Users/macbookpro/Documents/Projects/Perso/Michelle/soutenance/resources/views/layouts/partials/alert/success.blade.php ENDPATH**/ ?>