<?php if(session('info')): ?>

<div class="alert alert-primary" role="alert">

    <div class="alert-body">
        <strong><i class="me-1" data-feather="info"></i> Informations :</strong>
        <br>
        
        <?php echo e(session('info')); ?>

    </div>
</div>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\app\soutenance\resources\views/layouts/partials/alert/primary.blade.php ENDPATH**/ ?>