<?php $__env->startSection('breacrumd'); ?>
    <h2 class="content-header-title float-start mb-0">Tableau de bord</h2>
    <div class="breadcrumb-wrapper">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Tableau de bord</a>
            </li>
            <li class="breadcrumb-item active">Liste des visites
            </li>
        </ol>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="col-lg-12 col-12 order-2 order-lg-1">
    <div class="card">
        <div class="card-header">
            <h5>
            Liste des visites
            </h5>
        </div>
        <div class="card-body">

            <div class="row">
                <div class="col-md-6">

                </div>
                <div class="col-md-3 offset-md-3">
                    <input class="form-control" id="myInput" type="text" placeholder="Rechercher nom">
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered table-responsive table-striped mb-none mt-5"
                    id="datatable-default">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nom</th>
                            <th>Contact</th>
                            <th>Date</th>
                            <th>Message</th>
                            <th>Statut</th>
                            <th>Options</th>
                        </tr>
                    </thead>
                    <tbody id="myTable">

                        <?php $__currentLoopData = $visites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?> </td>

                                <td id="clientName"><?php echo e($visite->name ?? ''); ?></td>
                                <td><?php echo e($visite->phone); ?></td>
                                <td><?php echo e($visite->date); ?></td>
                                <td><?php echo e($visite->message); ?> </td>
                                <td><?php echo e($visite->status); ?> </td>
                                <td>
                                    <?php if($visite->status == 'Pending'): ?>
                                    <a href="<?php echo e(route('visite.valider',$visite->token)); ?>" class="btn btn-sm btn-success">Approuver</a>
                                    <a href="<?php echo e(route('visite.refuser',$visite->token)); ?>" class="btn btn-sm btn-warning">Rejeter</a>
                                    <?php endif; ?>

                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($visites->isEmpty()): ?>
                            <tr>
                                <td colspan="7" style="text-align: center">
                                    Aucune donnees de disponibles
                                </td>
                            </tr>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>
            <div class="my-2"><?php echo e($visites->links()); ?></div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbookpro/Documents/Projects/Perso/Michelle/soutenance/resources/views/admin/visites/index.blade.php ENDPATH**/ ?>