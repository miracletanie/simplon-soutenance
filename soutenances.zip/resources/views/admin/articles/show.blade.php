@extends('admin.articles.layouts')

@section('main')

    <div class="col-lg-12 col-12 order-2 order-lg-1">
        <div class="card">
            <div class="card-header">
                <h5>
                Information sur l'article
                </h5>
            </div>
            <div class="card-body">

                <div class="m-5">



                </div>

            </div>
        </div>
    </div>


@endsection
