<?php

return array (
  'navigations' => 'Navigations',
  'dashboard' => 'Tableau de bord',
  'menu_general' => 'Menu général',
  'ma_fiche' => 'Ma fiche',
  'services' => 'Services ALPA',
  'rendez_vous' => 'Rendez-vous',
  'activities' => 'Activités Alpa',
  'evenements' => 'Événements',
  'offres_demploi' => 'Offres d\'emploi',
  'offres_mentorat' => 'Offres de mentorat',
  'notifications' => 'Notifications',
  'interventions' => 'Interventions',
  'offres_bénévolat' => 'Offres de bénévolat',
  'offres_activites' => 'Offres d\'activités',
  'candidatures' => 'Candidatures',
  'informations' => 'Informations',
  'ressources' => 'Ressources',
);
