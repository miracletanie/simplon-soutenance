<?php

return array (
  'failed' => 'Ces informations d&#39;identification ne correspondent pas à nos dossiers.',
  'password' => 'Le mot de passe fourni est incorrect.',
  'throttle' => 'Trop de tentatives de connexion. Veuillez réessayer dans :seconds secondes.',
);
