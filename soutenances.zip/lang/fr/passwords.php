<?php

return array (
  'reset' => 'Votre mot de passe a été réinitialisé!',
  'sent' => 'Nous avons envoyé votre lien de réinitialisation de mot de passe par e-mail !',
  'throttled' => 'Veuillez patienter avant de réessayer.',
  'token' => 'Ce jeton de réinitialisation de mot de passe n\'est pas valide.',
  'user' => 'Nous ne trouvons pas d\'utilisateur avec cette adresse e-mail.',
);
