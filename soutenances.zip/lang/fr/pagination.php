<?php

return array (
  'next' => 'Suivant',
  'previous' => 'Précédent',
);
