<?php

return array (
    'name' => 'Nom',
    'status' => 'Statut',
    'activities' => 'Activités',
    'description' => 'Description',
    'options' => 'Options',
    'events' => 'Événements',
    'job' => 'Poste',
    'job_deadline' => 'Date limite',
    'mentor' => 'Mentor',
    'mentor_disponibility' => 'Disponibilité de / à',
    'agent' => 'Agent',
    'date' => 'Date',
    'start_hour' => 'Heure début',
    'end_hour' => 'Heure fin',
    'action' => 'Action',
  );
